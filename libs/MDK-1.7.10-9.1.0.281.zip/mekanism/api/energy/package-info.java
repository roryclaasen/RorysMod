@API(apiVersion = "9.0.0", owner = "Mekanism", provides = "MekanismAPI|energy")
package mekanism.api.energy;
import cpw.mods.fml.common.API;

